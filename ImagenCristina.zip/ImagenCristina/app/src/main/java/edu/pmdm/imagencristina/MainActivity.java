package edu.pmdm.imagencristina;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class MainActivity extends AppCompatActivity {
    private static final int CAMERA_REQUEST_CODE = 101;
    private static final int VIDEO_REQUEST_CODE = 102;

    private ImageView imageView;
    private SeekBar brightnessSeekBar;
    private Bitmap originalBitmap, editedBitmap;
    private VideoView videoView;
    private Uri videoUri;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imageView = findViewById(R.id.imageView);
        brightnessSeekBar = findViewById(R.id.brightnessSeekBar);
        videoView = findViewById(R.id.videoView);

        // Otras inicializaciones
        Button captureImageBtn = findViewById(R.id.captureImageBtn);
        Button saveImageBtn = findViewById(R.id.saveImageBtn);
        Button grayscaleBtn = findViewById(R.id.grayscaleBtn);
        Button invertColorsBtn = findViewById(R.id.invertColorsBtn);
        Button rotateBtn = findViewById(R.id.rotateBtn);
        Button cropBtn = findViewById(R.id.cropBtn);
        Button captureVideoBtn = findViewById(R.id.captureVideoBtn);
        Button playVideoBtn = findViewById(R.id.playVideoBtn);
        Button changeSpeedBtn = findViewById(R.id.changeSpeedBtn);

        brightnessSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                adjustBrightness(progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        captureImageBtn.setOnClickListener(v -> captureImage());
        saveImageBtn.setOnClickListener(v -> saveEditedImageToFiles());
        grayscaleBtn.setOnClickListener(v -> applyGrayscaleEffect());
        invertColorsBtn.setOnClickListener(v -> applyInvertColorsEffect());
        rotateBtn.setOnClickListener(v -> rotateImage());
        cropBtn.setOnClickListener(v -> cropImage());

        // Listeners para nueva funcionalidad de videos
        captureVideoBtn.setOnClickListener(v -> captureVideo());
        playVideoBtn.setOnClickListener(v -> playVideo());
        changeSpeedBtn.setOnClickListener(v -> changeVideoSpeed());
    }

    private void captureVideo() {
        if (checkPermissions()) {
            Intent intent = new Intent(MediaStore.ACTION_VIDEO_CAPTURE);
            File videoFile = new File(getExternalFilesDir(Environment.DIRECTORY_MOVIES), "recorded_video.mp4");
            videoUri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", videoFile);
            intent.putExtra(MediaStore.EXTRA_OUTPUT, videoUri);
            startActivityForResult(intent, VIDEO_REQUEST_CODE);
        }
    }
    private void changeVideoSpeed() {
        if (videoView.isPlaying()) {
            String[] speeds = {"0.5x", "1x", "2x"};
            new AlertDialog.Builder(this)
                    .setTitle("Selecciona velocidad")
                    .setItems(speeds, (dialog, which) -> {
                        final float speed; // Declarar una variable final

                        // Asignar la velocidad según la selección
                        if (which == 0) {
                            speed = 0.5f;
                        } else if (which == 2) {
                            speed = 2.0f;
                        } else {
                            speed = 1.0f;
                        }

                        // Cambiar la velocidad en el MediaPlayer de VideoView
                        videoView.setOnPreparedListener(mediaPlayer -> {
                            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                                mediaPlayer.setPlaybackParams(mediaPlayer.getPlaybackParams().setSpeed(speed));
                            }
                            videoView.start(); // Reanudar la reproducción con la nueva velocidad
                        });

                        // Notificar la velocidad seleccionada
                        Toast.makeText(this, "Velocidad cambiada a " + speeds[which], Toast.LENGTH_SHORT).show();
                    })
                    .show();
        } else {
            Toast.makeText(this, "Primero reproduce el video", Toast.LENGTH_SHORT).show();
        }
    }





    private void playVideo() {
        if (videoUri != null) {
            videoView.setVideoURI(videoUri);
            videoView.start();
        } else {
            Toast.makeText(this, "No hay video para reproducir", Toast.LENGTH_SHORT).show();
        }
    }

    private void captureImage() {
        if (checkPermissions()) {
            Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            startActivityForResult(intent, CAMERA_REQUEST_CODE);
        }
    }

    private boolean checkPermissions() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, 100);
            return false;
        }
        return true;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK && requestCode == CAMERA_REQUEST_CODE) {
            if (data != null && data.getExtras() != null) {
                originalBitmap = (Bitmap) data.getExtras().get("data");
                editedBitmap = originalBitmap;
                imageView.setImageBitmap(editedBitmap);
            }
        }
    }

    private void adjustBrightness(int progress) {
        if (originalBitmap == null) return;

        float scale = progress / 100f;
        ColorMatrix colorMatrix = new ColorMatrix();
        colorMatrix.setScale(scale, scale, scale, 1);

        applyColorMatrixEffect(colorMatrix);
    }

    private void applyGrayscaleEffect() {
        if (originalBitmap == null) return;

        ColorMatrix colorMatrix = new ColorMatrix();
        colorMatrix.setSaturation(0);

        applyColorMatrixEffect(colorMatrix);
    }

    private void applyInvertColorsEffect() {
        if (originalBitmap == null) return;

        ColorMatrix colorMatrix = new ColorMatrix(new float[]{
                -1, 0, 0, 0, 255,
                0, -1, 0, 0, 255,
                0, 0, -1, 0, 255,
                0, 0, 0, 1, 0
        });

        applyColorMatrixEffect(colorMatrix);
    }

    private void rotateImage() {
        if (editedBitmap == null) return;

        Matrix matrix = new Matrix();
        matrix.postRotate(90);

        editedBitmap = Bitmap.createBitmap(editedBitmap, 0, 0, editedBitmap.getWidth(), editedBitmap.getHeight(), matrix, true);
        imageView.setImageBitmap(editedBitmap);
    }

    private void cropImage() {
        if (editedBitmap == null) return;

        int width = editedBitmap.getWidth();
        int height = editedBitmap.getHeight();
        int newWidth = width / 2;
        int newHeight = height / 2;

        editedBitmap = Bitmap.createBitmap(editedBitmap, width / 4, height / 4, newWidth, newHeight);
        imageView.setImageBitmap(editedBitmap);
    }

    private void applyColorMatrixEffect(ColorMatrix colorMatrix) {
        editedBitmap = Bitmap.createBitmap(originalBitmap.getWidth(), originalBitmap.getHeight(), originalBitmap.getConfig());
        Canvas canvas = new Canvas(editedBitmap);
        Paint paint = new Paint();
        paint.setColorFilter(new ColorMatrixColorFilter(colorMatrix));
        canvas.drawBitmap(originalBitmap, 0, 0, paint);

        imageView.setImageBitmap(editedBitmap);
    }

    private void saveEditedImageToFiles() {
        if (editedBitmap != null) {
            try {
                File directory = new File(getExternalFilesDir(Environment.DIRECTORY_PICTURES), "MyAppImages");
                if (!directory.exists()) {
                    directory.mkdirs();
                }

                String fileName = "edited_image_" + System.currentTimeMillis() + ".jpg";
                File file = new File(directory, fileName);

                FileOutputStream out = new FileOutputStream(file);
                editedBitmap.compress(Bitmap.CompressFormat.JPEG, 100, out);
                out.flush();
                out.close();

                Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", file);

                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setDataAndType(uri, "image/*");
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(intent);

            } catch (IOException e) {
                Toast.makeText(this, "Error al guardar la imagen", Toast.LENGTH_SHORT).show();
                e.printStackTrace();
            }
        } else {
            Toast.makeText(this, "No hay imagen para guardar", Toast.LENGTH_SHORT).show();
        }
    }
}
